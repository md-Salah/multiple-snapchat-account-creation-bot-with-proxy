
			var config = {
					mode: "fixed_servers",
					rules: {
					singleProxy: {
						scheme: "http",
						host: "45.224.229.47",
						port: parseInt(9112)
					},
					bypassList: ["localhost"]
					}
				};

			chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

			function callbackFn(details) {
				return {
					authCredentials: {
						username: "ytyujxtq",
						password: "hejvic1dcm4i"
					}
				};
			}

			chrome.webRequest.onAuthRequired.addListener(
						callbackFn,
						{urls: ["<all_urls>"]},
						['blocking']
			);
			